{
    "printWidth": 100,
    "tabWidth": 2,
    "singleQuote": false,
    "semi": true,
    "trailingComma": "es5",
    "arrowParens": "avoid",
    "endOfLine": "auto"
  }
  